#pragma once
#include <QOpenGLShaderProgram>
#include <QMatrix4x4>
#include <QOpenGLExtraFunctions>
#include <QOpenGLBuffer>
#include <QOpenGLTexture>
#include <QOpenGLContext>
#ifdef _DEBUG
#include <QOpenGLDebugLogger>
#endif

#define GLFuncName QOpenGLExtraFunctions
